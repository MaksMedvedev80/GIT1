function clik() {
   let text = document.querySelector(".text");
   text.textContent = "Спасибо, что нажали на кнопку";
}

